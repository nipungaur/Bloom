# Bloom 🌱

A tiny garden that grows wherever you click.

**[Live demo →]()** *(add your deployed link here after hosting)*

## What it is

Bloom is an interactive web toy built for the GCSRM 2026 recruitment task (Option A). Click anywhere on the ground to plant a flower — it grows in with a spring animation and a soft chime. Move your cursor through the garden and the flowers lean away from it, like a breeze passing through. Flip the sky to night for stars and fireflies, or clear the whole garden and watch it wilt away.

## Features / interactions

- **Plant a flower** — click (or tap) the ground. Four species (daisy, tulip, poppy, bluebell) to choose from in the toolbar, or press `1`–`4`.
- **Wind sway** — flowers lean away from your cursor in real time as you move across the scene.
- **Day / Night toggle** — press the *Night* button or `N`. Swaps the whole palette, brings out stars and drifting fireflies.
- **Clear garden** — flowers wilt away one after another with a matching sound.
- **Sound effects** — every action has a small procedural sound, generated live with the Web Audio API (no audio files needed).
- **Saved garden** — your garden persists in `localStorage`, so it's still there next time you open the page.

## Tech stack

Plain HTML, CSS, and JavaScript. No frameworks, no build step, no external assets — flowers are drawn as inline SVG, sounds are synthesized with the Web Audio API.

## Run it locally

Just open `index.html` in a browser — that's it, nothing to install.

```bash
git clone <your-repo-url>
cd bloom
open index.html   # or double-click the file
```

## Deploy

Drag the folder into [Netlify Drop](https://app.netlify.com/drop), or push to a repo and import it into [Vercel](https://vercel.com/new), or turn on **GitHub Pages** in the repo settings (serving from the root of `main`). No build command needed.

## Notes

- Respects `prefers-reduced-motion`.
- Fully responsive down to small phone screens.
- Garden data and theme are stored under the `bloom-garden-v1` key in `localStorage`.
